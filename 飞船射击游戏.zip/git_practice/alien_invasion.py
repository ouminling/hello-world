import sys
import pygame

from settings import Settings  # 导入settings类
from ship import Ship   #导入ship类
from bullet import Bullet#导入bullet类

class ALienInvasion:
    '管理游戏资源和行为的类'

    def __init__(self):
        '初始化游戏并创建游戏'
        pygame.init()  # 初始化游戏背景
        self.settings = Settings()#创建一个Settings实例赋给self.setting


        self.screen = pygame.display.set_mode ((0,0),pygame.FULLSCREEN)#设置窗口大小(f)
        self.settings.screen_width = self.screen.get_rect().width#将显示器屏幕宽度赋给游戏窗口宽度大小设置
        self.settings.screen_height = self.screen.get_rect().height#将显示器屏幕高度赋给游戏窗口高度大小设置
        pygame.display.set_caption('ALien Invasion')

        self.ship = Ship(self)#调用Ship（）实例赋给
        self.bullets = pygame.sprite.Group()


    def run_game(self):
        '开始游戏主循环'
        while True:
            self._check_events()#调用_check_events()方法
            self.ship.update()#调用ship类的update方法
            self._update_bullets()#调用_update_bullets()方法
            self._update_screen()#调用_update_screen()方法



    def _check_events(self):#将检查玩家是否单击了关闭按钮的代码移到该方法
                # 监视键盘和鼠标事件.
                for event in pygame.event.get():  # 事件循环,pygame.eeeeeevent.get:返回一个列表（包含调用的所有事件）
                    if event.type == pygame.QUIT:  # 检测当用户点击关闭按钮，执行exit退出游戏
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:#pygame检测到KEYDOWN事件做出响应
                        self._check_keydown_events(event)
                    elif event.type == pygame.KEYUP:#pygame检测到KEYUP事件做出响应，如果玩家松开右箭头键（K_RIGHT），moving_right设置为右
                        self._check_keyup_events(event)

    def _check_keydown_events(self,event):
        '响应按键'
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = True
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = True
        elif event.key == pygame.K_q:
            sys.exit()
        elif event.key == pygame.K_SPACE:  # 当按动空格键调用_fire_bullet
            self._fire_bullet()


    def _check_keyup_events(self,event):
        '响应松开'
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = False
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = False

    def _fire_bullet(self):
        '创建一个子弹，并将其加入编组bullets中'
        if len(self.bullets) < self.settings.bullets_allowed:#如果bullets（子弹）长度小于设置的子弹数，创建子弹
            new_bullet = Bullet(self)  # 创建bullet实例赋给new_bullet
            self.bullets.add(new_bullet)  # 使用方法add（）加入编组bullet中

    def _update_bullets(self):
        '更新子弹的位置并删除消失的子弹'
        #更新子弹的位置
        self.bullets.update()  # bullets为编组bullets的每个子弹调用bullet.update（）

        # 删除最近消失的子弹。
        for bullet in self.bullets.copy():  # 由于python要求列表长度在循环中不可改变，所以我们copy（）列表，遍历副本实现修改bullets
            if bullet.rect.bottom <= 0:  # 检查子弹是否从屏幕顶部消失
                self.bullets.remove(Bullet)  # 从bullets删除bullet

    def _update_screen(self):#将更新屏幕图像的代码移到该方法
                # 每次循环重绘更新屏幕，并移到新屏幕
                self.screen.fill(self.settings.bg_color)  # 访问背景色。fill方法只接受一种实参：颜色
                self.ship.blitme()#调用ship.blitme()将飞船绘制到屏幕上
                for bullet in self.bullets.sprites():
                    bullet.draw_bullet() # 遍历bullet中的所有精灵，并对每个精灵调用draw_bullet（）
                # 让最近的绘制的屏幕可见
                pygame.display.flip()  # 不断更新屏幕，，隐藏旧屏幕，营造平滑移动的效果



if __name__ == '__main__':
    # 创建游戏实例并运行游戏
    ai = ALienInvasion()
    ai.run_game()

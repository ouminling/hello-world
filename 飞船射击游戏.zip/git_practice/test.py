L = ['Hello', 'World', 'IBM', 'Apple',18]

l=[]
for s in L:
if isinstance(s,str)==True:
l.append(s)
n=[m.lower() for m in l]
print(n)


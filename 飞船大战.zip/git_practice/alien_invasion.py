import sys
from time import  sleep
import pygame

from settings import Settings  # 导入settings类
from game_stats import GameStats## 导入game_stats类
from button import Button
from ship import Ship   #导入ship类
from bullet import Bullet#导入bullet类
from alien import Alien#导入alien类
from scoreboard import Scoreboard

class ALienInvasion:
    '管理游戏资源和行为的类'

    def __init__(self):
        '初始化游戏并创建游戏'
        pygame.init()  # 初始化游戏背景
        self.settings = Settings()#创建一个Settings实例赋给self.setting


        self.screen = pygame.display.set_mode ((0,0),pygame.FULLSCREEN)#设置窗口大小(f)
        self.settings.screen_width = self.screen.get_rect().width#将显示器屏幕宽度赋给游戏窗口宽度大小设置
        self.settings.screen_height = self.screen.get_rect().height#将显示器屏幕高度赋给游戏窗口高度大小设置
        pygame.display.set_caption('ALien Invasion')

        #创建一个用于存储游戏统计信息的实例
        self.stats = GameStats(self)
        self.sb = Scoreboard(self)#创建记分牌
        self.ship = Ship(self)#调用Ship（）实例赋给
        self.bullets = pygame.sprite.Group()
        self.aliens = pygame.sprite.Group()#创建了一个存储外星人的编组

        self._create_fleet()#调用—_creat_fleet_方法
        self.play_button = Button(self,"Play")#创建Play


    def run_game(self):
        '开始游戏主循环'
        while True:
            self._check_events()#调用_check_events()方法

            if self.stats.game_active:
                self.ship.update()  # 调用ship类的update方法
                self._update_bullets()  # 调用_update_bullets()方法
                self._update_aliens()  # 调用_update_aliens()方法

            self._update_screen()  # 调用_update_screen()方法




    def _check_events(self):#将检查玩家是否单击了关闭按钮的代码移到该方法
                # 监视键盘和鼠标事件.
                for event in pygame.event.get():  # 事件循环,pygame.eeeeeevent.get:返回一个列表（包含调用的所有事件）
                    if event.type == pygame.QUIT:  # 检测当用户点击关闭按钮，执行exit退出游戏
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:#pygame检测到KEYDOWN事件做出响应
                        self._check_keydown_events(event)
                    elif event.type == pygame.KEYUP:#pygame检测到KEYUP事件做出响应，如果玩家松开右箭头键（K_RIGHT），moving_right设置为右
                        self._check_keyup_events(event)
                    elif event.type == pygame.MOUSEBUTTONDOWN:#当玩家按下鼠标play按钮响应开始游戏
                        mouse_pos =pygame.mouse.get_pos()#返回一个元组（包含x坐标和y坐标）
                        self._check_play_button(mouse_pos)#传递给新方法_check_play_button

    def _check_keydown_events(self,event):
        '响应按键'
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = True
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = True
        elif event.key == pygame.K_q:
            sys.exit()
        elif event.key == pygame.K_SPACE:  # 当按动空格键调用_fire_bullet
            self._fire_bullet()


    def _check_keyup_events(self,event):
        '响应松开'
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = False
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = False

    def _fire_bullet(self):
        '创建一个子弹，并将其加入编组bullets中'
        if len(self.bullets) < self.settings.bullets_allowed:#如果bullets（子弹）长度小于设置的子弹数，创建子弹
            new_bullet = Bullet(self)  # 创建bullet实例赋给new_bullet
            self.bullets.add(new_bullet)  # 使用方法add（）加入编组bullet中

    def _update_bullets(self):
        '更新子弹的位置并删除消失的子弹'
        #更新子弹的位置
        self.bullets.update()  # bullets为编组bullets的每个子弹调用bullet.update（）

        # 删除最近消失的子弹。
        for bullet in self.bullets.copy():  # 由于python要求列表长度在循环中不可改变，所以我们copy（）列表，遍历副本实现修改bullets
            if bullet.rect.bottom <= 0:  # 检查子弹是否从屏幕顶部消失
                self.bullets.remove(Bullet)  # 从bullets删除bullet
        self._check_bullet_alien_collisions()
        #检查是否有子弹击中了外星人
        # 如果是，就删除相应的子弹和外星人。



    def _check_bullet_alien_collisions(self):
        '响应子弹和外星人碰撞'
        #删除碰撞的外星人和子弹
        collisions = pygame.sprite.groupcollide(
            self.bullets, self.aliens, True,
            True)  # 使用groupcollide比较bullets和aliens里两个编组的元素，第一个true是碰撞后bullets消失，第二给aliens消失
        if collisions:#当子弹击中外星人时，返回一个字典（collisions）
            for aliens in collisions.values():
                self.stats.score += self.settings.alien_points * len(aliens)
                self.sb.prep_score()#创建最新得分的图像
                self.sb.check_high_score()#消灭外星人更新得分后调用check_high_score（）
        if not self.aliens:
            '删除现有的子弹并新建一群外星人'
            self.bullets.empty()
            self._create_fleet()
            self.settings.increase_speed()#调用settings里的incre_speed（）加快游戏节奏

            #提高等级
            self.stats.level += 1#当消灭全部外星人后等级+1
            self.sb.prep_level()#调用prep_level()显示新等级

    def _create_fleet(self):
        '创建外星人群'
        #创建一行外星人并计算一行可容纳多少个外星人
        #外星人的间距为外星人宽度
        alien = Alien(self)#创建外星人
        alien_width,alien_height= alien.rect.size#获取外星人的宽度和高度
        avaliable_space_x = self.settings.screen_width - (2 * alien_width)#计算可以放置多少个外星人
        number_aliens_x = avaliable_space_x // (2*alien_width)

        #计算屏幕可容纳多少行外星人。
        ship_height = self.ship.rect.height
        avaliable_space_y = (self.settings.screen_height -
                             (3 * alien_height) - ship_height)
        number_rows = avaliable_space_y // (2 * alien_height)

        #创建外星人群.
        for row_number in range(number_rows):#外层循环从0开始数要创建的外星人数
            # 创建第一行外星人
            for alien_number in range(number_aliens_x):  # 从0开始创建一行外星人数
                '创建一个外星人并加入当前行'
                self._creat_alien(alien_number,row_number)


    def _creat_alien(self,alien_number,row_number):#alien_number接受创建的外星人的编号
        '创建一个外星人并将其放在当前行'
        alien = Alien(self)
        alien_width,alien_hight= alien.rect.size
        alien.x = alien_width + 2 * alien_width * alien_number
        alien.rect.x = alien.x
        alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
        self.aliens.add(alien)

    def _check_fleet_edges(self):
        '有外星人到达边缘采取相应措施'
        for alien in self.aliens.sprites():#遍历外星人群并对每个外星人调用check_edges（）
            if alien.check_edges():
                self._change_fleet_direction()#使用_change_fleet_direction()退出循环，改变方向
                break

    def _change_fleet_direction(self):
        '将整群外星人向下移，并改变他们的方向'
        for alien in self.aliens.sprites():
            alien.rect.y += self.settings.fleet_drop_speed
        self.settings.fleet_direction *= -1

    def _update_aliens(self):
        '检查外星人是否在屏幕边缘和更新外星人群的所有外星人的位置'
        self._check_fleet_edges()
        self.aliens.update()

        #检测外星人和飞船是否碰撞。
        if pygame.sprite.spritecollideany(self.ship,self.aliens):
            self._ship_hit()
        #检查是否有外星人到达了底部
        self._check_aliens_bottom()

    def _ship_hit(self):
        '响应飞船被外星人撞到'
        if self.stats.ships_left >0:
            # 将ship_left减1并更新记分牌
            self.stats.ships_left -= 1  # 相撞时飞船数-1
            self.sb.prep_ships()#更新记分牌
            # 清除余下的外星人和子弹
            self.aliens.empty()
            self.bullets.empty()

            # 创建一群新的外星人，将飞船放在屏幕底部中间
            self._create_fleet()
            self.ship.center_ship()
            # 暂停
            sleep(0.5)
        else:
            self.stats.game_active = False
            pygame.mouse.set_visible(True)#游戏结束后显示鼠标光标



    def _check_aliens_bottom(self):
        '检查是否有外星人到达屏幕底部'
        screen_rect =self.screen.get_rect()
        for alien in self.aliens.sprites():
            if alien.rect.bottom >= screen_rect.bottom:#外星人rect.bottom>=屏幕的rect.bottom时
                '调用飞船碰撞ship_hit()方法处理'
                self._ship_hit()
                break

    def _check_play_button(self,mouse_pos):
        '在玩家单击Play按钮时开始新游戏'
        button_clicked = self.play_button.rect.collidepoint(mouse_pos)
        if button_clicked and not self.stats.game_active:
            '重置游戏数据'
            self.settings.initialize_dynamic_settings()
            '重置游戏统计信息'
            self.stats.reset_stats()
            self.stats.game_active = True
            self.sb.prep_score()#开始游戏时，得分置零
            self.sb.prep_level()
            self.sb.prep_ships()

            #清空余下的外星人和子弹
            self.aliens.empty()
            self.bullets.empty()

            #创建一群外星人并让飞船居中
            self._create_fleet()
            self.ship.center_ship()

            #隐藏鼠标光标
            pygame.mouse.set_visible(False)

    def _update_screen(self):#将更新屏幕图像的代码移到该方法
                # 每次循环重绘更新屏幕，并移到新屏幕
                self.screen.fill(self.settings.bg_color)  # 访问背景色。fill方法只接受一种实参：颜色
                self.ship.blitme()#调用ship.blitme()将飞船绘制到屏幕上
                for bullet in self.bullets.sprites():
                    bullet.draw_bullet() # 遍历bullet中的所有精灵，并对每个精灵调用draw_bullet（）
                self.aliens.draw(self.screen)#在屏幕绘制外星人

                #显示得分
                self.sb.show_score()

                #如果游戏在非活动状态，就绘制Play按钮
                if not  self.stats.game_active:
                    self.play_button.draw_button()#显示在屏幕上
                # 让最近的绘制的屏幕可见
                pygame.display.flip()  # 不断更新屏幕，，隐藏旧屏幕，营造平滑移动的效果



if __name__ == '__main__':
    # 创建游戏实例并运行游戏
    ai = ALienInvasion()
    ai.run_game()

import pygame
from pygame.sprite import Sprite

class Alien(Sprite):
    '表示单个外星人的类'
    def __init__(self,ai_game):
        '初始化外星人并设置起始位置'
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings

        #加载外星人图像并设置rect属性。
        self.image = pygame.image.load('images/alien.bmp')
        self.rect = self.image.get_rect()

        #每个外星人最初都在屏幕左上角附近
        self.rect.x = self.rect.width#左边距为外星人宽度
        self.rect.y = self.rect.height#右边距为外星人高度

        #存储外星人的精确水平位置
        self.x = float(self.rect.x)#精确记录水平位置是为了水平速度


    def check_edges(self):#判断外星人在屏幕左边缘或屏幕右边缘
        '如果外星人处于屏幕边缘，就返回true'
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right or self.rect.left < 0:
            return True
    def update(self):
        '向左或右移动外星人'

        self.x += (self.settings.alien_speed * self.settings.fleet_direction)#使用属性self.x跟踪每个外星人的准确位置，当fleet_direction为1外星人x坐标增大alien_speed,为-1外星人向x左移动
        self.rect.x = self.x#使用self.x来更新外星人rect的值
